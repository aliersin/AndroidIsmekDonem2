package com.ismek.ismekdonem.listener;

import android.view.View;

public interface HaberListener {

    public void onDetail(View view, int position);
}
