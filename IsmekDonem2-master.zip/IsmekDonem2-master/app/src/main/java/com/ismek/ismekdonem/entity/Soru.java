package com.ismek.ismekdonem.entity;

public class Soru {

    private String soru;
    private String secenek1;
    private String secenek1Puan;

    private String secenek2;
    private String secenek2Puan;

    private String secenek3;
    private String secenek3Puan;

    public String getSoru() {
        return soru;
    }

    public void setSoru(String soru) {
        this.soru = soru;
    }

    public String getSecenek1() {
        return secenek1;
    }

    public void setSecenek1(String secenek1) {
        this.secenek1 = secenek1;
    }

    public String getSecenek1Puan() {
        return secenek1Puan;
    }

    public void setSecenek1Puan(String secenek1Puan) {
        this.secenek1Puan = secenek1Puan;
    }

    public String getSecenek2() {
        return secenek2;
    }

    public void setSecenek2(String secenek2) {
        this.secenek2 = secenek2;
    }

    public String getSecenek2Puan() {
        return secenek2Puan;
    }

    public void setSecenek2Puan(String secenek2Puan) {
        this.secenek2Puan = secenek2Puan;
    }

    public String getSecenek3() {
        return secenek3;
    }

    public void setSecenek3(String secenek3) {
        this.secenek3 = secenek3;
    }

    public String getSecenek3Puan() {
        return secenek3Puan;
    }

    public void setSecenek3Puan(String secenek3Puan) {
        this.secenek3Puan = secenek3Puan;
    }
}
